//
//  SettingsViewController.swift
//  GiveJoy
//
//  Created by iphtech7 on 10/15/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var editProfileButton: UIButton!
    @IBOutlet weak var manageCardsButton: UIButton!
    @IBOutlet weak var getHelpButton: UIButton!
    @IBOutlet weak var termsOfUseButton: UIButton!
    @IBOutlet weak var filterButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
      backButton.tintColor = .white
        filterButton.tintColor = .white
        // Do any additional setup after loading the view.
    }
   
    @IBAction func backButtonAction(_ sender: Any) {
    }
    
    @IBAction func filterButtonAction(_ sender: Any) {
    }
    
    @IBAction func editProfileButtonAction(_ sender: Any) {
    }
    
    @IBAction func manageCardsButtonAction(_ sender: Any) {
    }
    
    @IBAction func getHelpButtonAction(_ sender: Any) {
    }
    
    @IBAction func termsOfUseButtonAction(_ sender: Any) {
    }
    @IBAction func logOutButtonACtion(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
