//
//  EditProfileViewController.swift
//  GiveJoy
//
//  Created by iphtech7 on 10/15/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class EditProfileViewController: UIViewController {

    @IBOutlet weak var fullNameTextField: CustomTextField!
    @IBOutlet weak var genderTextField: CustomTextField!
    @IBOutlet weak var phoneTextField: CustomTextField!
    @IBOutlet weak var emailTextField: CustomTextField!
    @IBOutlet weak var cityTextField: CustomTextField!
    @IBOutlet weak var addressTextField: CustomTextField!
    @IBOutlet weak var cancelButton: CustomButton!
    @IBOutlet weak var saveButton: CustomButton!
    @IBOutlet weak var backButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.fullNameTextField.setShadow()
        self.genderTextField.setShadow()
        self.phoneTextField.setShadow()
        self.emailTextField.setShadow()
        self.cityTextField.setShadow()
        self.addressTextField.setShadow()
        
        self.backButton.tintColor = .purple
        self.fullNameTextField.setLeftPaddingPoints(10)
        self.genderTextField.setLeftPaddingPoints(10)
        self.phoneTextField.setLeftPaddingPoints(10)
        self.emailTextField.setLeftPaddingPoints(10)
        self.cityTextField.setLeftPaddingPoints(10)
        self.addressTextField.setLeftPaddingPoints(10)
        
        self.fullNameTextField.setBackGroundColor(color: .white)
        self.genderTextField.setBackGroundColor(color: .white)
        self.addressTextField.setBackGroundColor(color: .white)
        self.cityTextField.setBackGroundColor(color: .white)
        self.phoneTextField.setBackGroundColor(color: .white)
        self.emailTextField.setBackGroundColor(color: .white)
        
         self.cancelButton.setCornerRadiusView(radius: 15)
        self.saveButton.setCornerRadiusView(radius: 15)
        
       self.saveButton.setBackGroundColor(color: .purple)
        self.cancelButton.setBackGroundColor(color: .lightGray)
        
        
        // Do any additional setup after loading the view.
    }
 
    @IBAction func cancelButtonAction(_ sender: Any) {
    }
    
    @IBAction func saveButtonAction(_ sender: Any) {
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
    }
    
}
