//
//  Constants.swift
//  GiveJoy
//
//  Created by Nitin Sharma on 09/10/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import Foundation

enum FontName:String{
    case LATO_BOLD = "Lato-Bold"
    case LATO_BLACK = "Lato-Black"
}

let  ALLOWED_PHONE_NUMBER_DIGITS = 10//11
let PLACEHOLDER_COLOR = "#7476A5"
let  WARNING_COLOR = "#B9BAD2"
let ERROR_COLOR = "#FF3576"
let ACTIVE_COLOR = "#00D3B8"
let INACTIVE_COLOR = "#9B9B9B"
let THEME_COLOR = "#1C172F"
