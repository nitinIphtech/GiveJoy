//
//  CustomTextField.swift
//  GiveJoy
//
//  Created by Nitin Sharma on 09/10/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class CustomTextField: UITextField {
    let color = UIColor(hexString: "#F1F1F6")
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
        setShadow()
    }
    
    public func setAttributedPlaceHolder(text:String){
        self.attributedPlaceholder = NSAttributedString(string: text,attributes: [NSAttributedString.Key.foregroundColor: UIColor(hexString: PLACEHOLDER_COLOR)])
    }
    
    private func setupView(){
        self.backgroundColor = color
        self.font = UIFont(name:  FontName.LATO_BOLD.rawValue, size: 16.0)
        self.textColor = UIColor.black
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.cornerRadius = 10
        self.clipsToBounds = true
    }
    
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
     func setShadow(){
//        self.layer.borderColor = UIColor.black.withAlphaComponent(0.25).cgColor
//        self.layer.shadowOffset = CGSize(width: 0, height: 10)
//        self.layer.shadowColor = UIColor.red.cgColor //Any dark color
//        self.clipsToBounds = true
        
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.borderWidth = 1.0
        self.layer.borderColor = UIColor(white: 0.5, alpha: 0.3).cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 25
        self.layer.shadowOffset = CGSize(width: 0, height: 4)
        self.layer.shadowColor = UIColor.lightGray.cgColor
        self.clipsToBounds = true
        

    }
   public func setBackGroundColor(color:UIColor)
    {
        self.backgroundColor = color
        
    }
}
//layer.shadowOffset = CGSize(width: 0, height: 0)
//layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor
//layer.shadowOpacity = 1
//layer.shadowRadius = 25
////        layer.shadowPath = CGPath(roundedRect: bounds, cornerWidth: cornerHeight, cornerHeight: cornerHeight, transform: nil)
//layer.cornerRadius = 20
