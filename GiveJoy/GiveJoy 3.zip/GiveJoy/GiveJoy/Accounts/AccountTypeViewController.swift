

import UIKit

class AccountTypeViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var pageController: UIPageControl!
    @IBOutlet weak var collectionVw: UICollectionView!
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var theBestWayLabel: UILabel!
    
    let cellIdentifier = "WelcomeCollectionCell"
    @IBOutlet weak var signUpButton: CustomButton!
    @IBOutlet weak var loginButton: CustomButton!
    var timer = Timer()
    var counter = 0
    var color = [UIColor.red,UIColor.blue,UIColor.purple,UIColor.gray,UIColor.yellow]
    override func viewDidLoad() {
        super.viewDidLoad()

        
        signUpButton.layer.cornerRadius = 20
        loginButton.layer.cornerRadius = 20
        welcomeLabel.textColor = UIColor.white
        theBestWayLabel.textColor = UIColor.white

        self.collectionVw.register(UINib(nibName: self.cellIdentifier, bundle: nil), forCellWithReuseIdentifier: self.cellIdentifier)
        self.collectionVw.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)

        pageController.numberOfPages = 5
        pageController.currentPage = 0
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.changeImage), userInfo: nil, repeats: true)
        }
        collectionVw.reloadData()
    }
    @objc func changeImage(){
        if counter < color.count {
            let index = IndexPath.init(item: counter, section: 0)
            self.collectionVw.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
            pageController.currentPage = counter
            counter += 1
        } else {
            counter = 0
            let index = IndexPath.init(item: counter, section: 0)
            self.collectionVw.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
            pageController.currentPage = counter
            counter = 1
        }
    }
    
 
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return color.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.collectionVw.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath)
        as! WelcomeCollectionCell
        cell.containerView.backgroundColor  = color[indexPath.row]
        
        return cell
    }
    
    private func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
    {
        
        return  CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    @IBAction func signUpButtonTapped(_ sender: Any) {
        let destination = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        self.navigationController?.pushViewController(destination, animated: true)
    }
    @IBAction func loginButtonTapped(_ sender: Any) {
        let destination = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(destination, animated: true)
        
    }
}
