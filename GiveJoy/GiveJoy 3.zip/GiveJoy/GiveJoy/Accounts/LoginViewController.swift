//
//  LoginVC.swift
//  GiveJoy
//
//  Created by Nitin Sharma on 08/10/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var continueButton: CustomButton!
    @IBOutlet weak var emiilTextField: CustomTextField!
    @IBOutlet weak var passwordTextField: CustomTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.emiilTextField.setShadow()
        self.passwordTextField.setShadow()
        self.emiilTextField.setLeftPaddingPoints(10)
        self.passwordTextField.setLeftPaddingPoints(10)
        self.emiilTextField.setBackGroundColor(color: .white)
        self.passwordTextField.setBackGroundColor(color: .white)
       
        self.continueButton.setCornerRadiusView(radius: 25)

    }
    @IBAction func forgotButtonTapped(_ sender: Any) {
    }
    @IBAction func continueButtonTapped(_ sender: Any) {
    }
    @IBAction func signUpButtonTapped(_ sender: Any) {
        let destination = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        self.navigationController?.pushViewController(destination, animated: true)
    }
    

}
