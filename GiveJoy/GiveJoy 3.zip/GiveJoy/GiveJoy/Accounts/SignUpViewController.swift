//
//  SignUpVC.swift
//  GiveJoy
//
//  Created by Nitin Sharma on 08/10/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {
    @IBOutlet weak var nametextField: CustomTextField!
    @IBOutlet weak var emailTextField: CustomTextField!
    @IBOutlet weak var passwordTextField: CustomTextField!
    @IBOutlet weak var continueButton: CustomButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.nametextField.setShadow()
        self.passwordTextField.setShadow()
        self.emailTextField.setShadow()
        self.nametextField.setLeftPaddingPoints(10)
        self.emailTextField.setLeftPaddingPoints(10)
        self.passwordTextField.setLeftPaddingPoints(10)

        self.nametextField.setBackGroundColor(color: .white)
        self.passwordTextField.setBackGroundColor(color: .white)
        self.emailTextField.setBackGroundColor(color: .white)
  
        self.continueButton.setCornerRadiusView(radius: 25)

    }
    @IBAction func continueButtonTapped(_ sender: Any) {
    }
    @IBAction func loginButtonTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
