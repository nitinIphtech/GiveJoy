//
//  FriendsViewController.swift
//  GiveJoy
//
//  Created by Nitin Sharma on 11/10/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class FriendsViewController: UIViewController {
    @IBOutlet weak var phoneFriendsView: UIView!
    @IBOutlet weak var giveJoyFriends: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var phoneContactButton: UIButton!
    @IBOutlet weak var giveJoyFriendsButton: UIButton!
    var contentSize  = 0.0
    var contentOffset = CGPoint.zero

    override func viewDidLoad() {
        super.viewDidLoad()
//    self.scrollView.delegate = self
        
    }
    @IBAction func phoneContactButtonTapped(_ sender: UIButton) {
    }
    @IBAction func giveKoyButtonTapped(_ sender: Any) {
    }
    
}
