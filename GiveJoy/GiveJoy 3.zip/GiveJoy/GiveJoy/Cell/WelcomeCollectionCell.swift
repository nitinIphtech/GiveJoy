//
//  CollectionViewCell.swift
//  GiveJoy
//
//  Created by Nitin Sharma on 08/10/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class WelcomeCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var containerView: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
