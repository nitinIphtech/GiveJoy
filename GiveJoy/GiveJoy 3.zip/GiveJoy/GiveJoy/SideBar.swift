//
//  SideBar.swift
//  GiveJoy
//
//  Created by Nitin Sharma on 11/10/19.
//  Copyright © 2019 Nitin Sharma. All rights reserved.
//

import UIKit

class SideBar: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameTitleLabel: UILabel!
    @IBOutlet weak var emailTitleLabel: UILabel!
    @IBOutlet weak var giftBalanceLabel: UILabel!
    @IBOutlet weak var transeferToBankButton: UIButton!
    var titlList = ["Home","Edit Profile","Store","Basket","My Gift","Create Post","Firends"]
    var imageList = ["home","editProfile","store","basket","myGifts","editProfile","editProfile"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.profileImageView.layer.cornerRadius = 12
        profileImageView.clipsToBounds = true
        self.transeferToBankButton.layer.cornerRadius = 12
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titlList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "sideMenuTableViewCell", for: indexPath) as! SideMenuTableViewCell
        cell.sideMenuTitleLabel.text! = titlList[indexPath.row]
        cell.sideMenuImageView.image = UIImage(named: imageList[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let destination = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
//            self.navigationController?.pushViewController(destination, animated: true)
            self.present(destination, animated: true, completion: nil)
        }
        else if indexPath.row == 1 {
        }
        else if indexPath.row == 2 {
        }
        else if indexPath.row == 3 {
        }
        else if indexPath.row == 4 {
        }
        else if indexPath.row == 5 {
        }
        else if indexPath.row == 6 {
            let destination = self.storyboard?.instantiateViewController(withIdentifier: "FriendsViewController") as! FriendsViewController
            //            self.navigationController?.pushViewController(destination, animated: true)
            self.present(destination, animated: true, completion: nil)
        }
        
        
    }
    @IBAction func transeferToBankButtonTapped(_ sender: Any) {
    }
    

}
