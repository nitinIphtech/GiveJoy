//
//  StringExtension.swift
//  Rendezvous
//
//  Created by iPHTech 33 on 15/03/19.
//  Copyright © 2019 iPHTech 33. All rights reserved.
//
import Foundation
extension String {
    var isBackspace: Bool {
        let char = self.cString(using: String.Encoding.utf8)!
        return strcmp(char, "\\b") == -92
    }
}
